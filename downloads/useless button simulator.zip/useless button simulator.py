import tkinter as tk
from tkinter import ttk
from tkinter import * 

root = Tk()

root.geometry("600x250")

root.resizable(False, False)

# This is the section of code which creates the main window
root.geometry('890x559')
root.configure(background='#0000FF')
root.title('click a pointless button simulator')

# This is the section of code which creates the a label
Label(root, text='useless button simulator', bg='#FFC0CB', font=('arial', 50, 'normal')).place(x=38, y=18)

tk.Button(root, 
          text = "useless button", 
          height = 6, 
          width = 20).place(x=400, y=250)

root.mainloop()